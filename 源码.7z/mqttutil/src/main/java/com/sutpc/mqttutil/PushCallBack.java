package com.sutpc.mqttutil;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;

/**
 * @Author:chenzhiyuan
 * @Date: Created in 22:02 2020-06-05
 * @Description 发布消息的回调类.
 * @Modified By:
 */
public class PushCallBack implements MqttCallback {

  /**
   * 表示该消费者所消费的消息数
   */
  private static int num = 0;

  // 在断开连接时调用
  public void connectionLost(Throwable cause) {
    // 连接丢失后，一般在这里面进行重连
    System.out.println("连接已断开，请重连...");
  }

  // 接收到已经发布的 QoS 1 或 QoS 2 消息的传递令牌时调用
  public void deliveryComplete(IMqttDeliveryToken token) {
    System.out.println("消息分发完毕，token值为：" + token.isComplete());
  }

  // 接收已经预订的发布
  public void messageArrived(String topic, MqttMessage message) {
    // subscribe后得到的消息会执行到这里面
    String content = new String(message.getPayload());
    System.out.println("接收的第" + ++num + "条消息");
    System.out.println("接收消息主题 : " + topic);
    System.out.println("接收消息Qos : " + message.getQos());
    System.out.println("接收消息内容 : " + content);
  }

}
