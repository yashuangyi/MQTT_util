package com.sutpc.mqttutil;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttTopic;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * @Author:chenzhiyuan
 * @Date: Created in 22:02 2020-06-05
 * @Description 消费者测试类.
 * @Modified By:
 */
public class ClientUtil {

  /**
   * MQTT安装的服务器地址:MQTT定义的端口号
   */
  private static String host;

  /**
   * 消费者所指定接收的主题
   */
  private static String topic;

  /**
   * 消费者登录用户名
   */
  private static String userName;

  /**
   * 消费者登录密码
   */
  private static String passWord;

  /**
   * 定义MQTT的ID（用于区分接收消息的消费者）
   */
  private static String clientId;

  /**
   * 消息代理对象
   */
  private MqttClient proxy;

  /**
   * 连接的配置对象
   */
  private MqttConnectOptions options;

  public static void main(String[] args) {
    ClientUtil client = new ClientUtil();
    client.start();
  }

  void start(){
    try{
      FileInputStream in = new FileInputStream(System.getProperty("user.dir")+ File.separator+"config.properties");
      Properties properties = new Properties();
      properties.load(in);
      host = "tcp://" + properties.getProperty("mqtt.ip") + ":" + properties.getProperty("mqtt.port");
      topic = properties.getProperty("client.topic");
      userName = properties.getProperty("client.userName");
      passWord = properties.getProperty("client.passWord");
      clientId = properties.getProperty("client.clientId");
    }catch (Exception e){
      System.out.println("请确保jar包同目录下有config.properties文件！");
    }

    try {
      // host为主机名，clientId即连接MQTT的客户端ID，一般以唯一标识符表示，MemoryPersistence设置clientId的保存形式，默认为以内存保存
      proxy = new MqttClient(host, clientId, new MemoryPersistence());
      // MQTT的连接设置
      options = new MqttConnectOptions();
      // 设置是否清空session,这里如果设置为false表示服务器会保留客户端的连接记录，这里设置为true表示每次连接到服务器都以新的身份连接
      options.setCleanSession(true);
      // 设置连接的用户名
      options.setUserName(userName);
      // 设置连接的密码
      options.setPassword(passWord.toCharArray());
      // 设置超时时间 单位为秒
      options.setConnectionTimeout(50);
      // 设置会话心跳时间 单位为秒 服务器会每隔1.5*60秒的时间向客户端发送个消息判断客户端是否在线，但这个方法并没有重连的机制
      options.setKeepAliveInterval(60);
      // 设置回调
      proxy.setCallback(new PushCallBack());
      MqttTopic topicObject = proxy.getTopic(topic);
      //setWill方法，如果项目中需要知道客户端是否掉线可以调用该方法。设置最终端口的通知消息
      options.setWill(topicObject, "close".getBytes(), 0, true);

      proxy.connect(options);
      //订阅消息
      int[] qos = {1};
      String[] topics = {topic};
      proxy.subscribe(topics, qos);

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
