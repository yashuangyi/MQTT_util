package com.sutpc.mqttutil;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * @Author:chenzhiyuan
 * @Date: Created in 22:01 2020-06-05
 * @Description 生产者测试端.
 * @Modified By:
 */
public class ServerUtil {

  /**
   * 代表该生产者发出的消息数
   */
  private static int num = 0;

  /**
   * MQTT安装的服务器地址:MQTT定义的端口号
   */
  private static String host;

  /**
   * 生产者所发送的主题
   */
  private static String topic;

  /**
   * 生产者登录用户名
   */
  private static String userName;

  /**
   * 生产者登录密码
   */
  private static String passWord;

  /**
   * 生产者所发送的消息内容文本
   */
  private static String message;

  /**
   * 定义MQTT的ID（用于区分发送消息的生产者）
   */
  private static String clientId;

  /**
   * 消息代理对象
   */
  private MqttClient proxy;

  /**
   * 生产者所发送的消息对象
   */
  private MqttMessage messageObject;

  /**
   * 生产者所发送的
   */
  private MqttTopic topicObject;

  /**
   * 构造函数
   * @throws MqttException
   */
  ServerUtil() throws MqttException {
    proxy = new MqttClient(host, clientId, new MemoryPersistence());
    connect();
  }

  /**
   * 启动类
   * @param args
   */
  public static void main(String[] args) throws MqttException, InterruptedException {
    // 读取配置文件
    try {
      FileInputStream in = new FileInputStream(System.getProperty("user.dir")+ File.separator+"config.properties");
      Properties properties = new Properties();
      properties.load(in);
      host = "tcp://" + properties.getProperty("mqtt.ip") + ":" + properties.getProperty("mqtt.port");
      topic = properties.getProperty("server.topic");
      userName = properties.getProperty("server.userName");
      passWord = properties.getProperty("server.passWord");
      clientId = properties.getProperty("server.clientId");
      message = new String(properties.getProperty("server.message").getBytes("ISO-8859-1"),"UTF-8");
    }catch (Exception e){
      System.out.println("请确保jar包同目录下有config.properties文件！");
    }

    ServerUtil server = new ServerUtil();

    // 间隔1s发送一次消息
    while(true){
      server.messageObject = new MqttMessage();
      // 消息的服务质量，0表示至多一次；1表示至少一次；2表示仅一次；3表示预留
      server.messageObject.setQos(2);
      // 发布保留标识，表示服务器要保留本次推送信息
      server.messageObject.setRetained(true);
      // 消息内容文本
      server.messageObject.setPayload(message.getBytes());
      // 发布
      server.publish(server.topicObject , server.messageObject);

      System.out.println("第" + ++num + "条信息发送成功");
      Thread.sleep(1000);
    }
  }

  /**
   * 连接消息中间件
   */
  void connect() throws MqttException {
    MqttConnectOptions options = new MqttConnectOptions();
    options.setCleanSession(false);
    options.setUserName(userName);
    options.setPassword(passWord.toCharArray());
    // 设置超时时间
    options.setConnectionTimeout(10);
    // 设置会话心跳时间
    options.setKeepAliveInterval(20);
    proxy.setCallback(new PushCallBack());
    proxy.connect(options);
    topicObject = proxy.getTopic(topic);
  }

  /**
   * 发布消息
   * @param topic
   * @param message
   */
  void publish(MqttTopic topic, MqttMessage message) throws MqttException {
    MqttDeliveryToken token = topic.publish(message);
    token.waitForCompletion();
    System.out.println("消息发布成功！内容：" + new String(message.getPayload()));
  }

}
